# 1. Print your name at the top of the script
print("Tianyu Zhang")
# 2. Install the vcd package
install.packages("vcd")

# 3. Import the vcd library
library(grid)
library(vcd)
library(readr)
# 4. Plot an age ~ salary scatter plot using the data below
age <- c(27,30,23,45,35,42,19,18,50,60)
salary <- c(69000,80000,50000,84000,80000,200000,30000,25000,150000,120000)
plot(age, salary, xlab = "Age", ylab = "Salary", main = "Age vs Salary Scatter Plot")
# 5. Find the mean and median salary
mean_salary <- mean(salary)
mean(salary)
median_salary <- median(salary)
median(salary)
# 6. Delete the 6th element from the salary vector
salary <- salary[-6]
salary
# 7. Insert 150000 as the 6th element into the salary vector
salary <- c(salary[1:5], 150000, salary[6:10])
salary
# 8. Create a vector <movies> with elements Lord of Ring, Harry Pottery, Top Gun
movies <- c("Lord of Ring", "Harry Pottery", "Top Gun")
movies
# 9. Create a 7 row and 5 column matrix of 35 integers from 1 to 35
matrix <- matrix(1:35, nrow = 7, ncol = 5)
matrix
# 10. Create a data frame <employee> with age and salary attributes
employee <- data.frame(age = c(27,30,23,45,35,42,19,18,50,60) , 
                       salary = c(69000,80000,50000,84000,80000,150000,30000,25000,150000,120000) )
# 11. Display the data frame structure and summary of the employee data frame
str(employee)
summary(employee)
# 12. Import the dataset bank.csv
bank <- read_csv("bank.csv")
# 13. Display only the variable names of the bank.csv dataset
colnames(bank)



